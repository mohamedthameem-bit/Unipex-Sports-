import { Navbar } from './components/layout/Navbar'
import { Footer } from './components/layout/Footer'
import { Hero } from './components/sections/Hero'
import { Collections } from './components/sections/Collections'
import { CustomJersey } from './components/sections/CustomJersey'
import { About } from './components/sections/About'
import { Reviews } from './components/sections/Reviews'
import { Gallery } from './components/sections/Gallery'
import { VisitStore } from './components/sections/VisitStore'
import { JsonLd } from './components/seo/JsonLd'

export default function App() {
  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:bg-lime focus:px-4 focus:py-2 focus:font-bold focus:text-pitch"
      >
        Skip to content
      </a>
      <JsonLd />
      <Navbar />
      <main id="main">
        <Hero />
        <Collections />
        <CustomJersey />
        <About />
        <Reviews />
        <Gallery />
        <VisitStore />
      </main>
      <Footer />
    </>
  )
}
