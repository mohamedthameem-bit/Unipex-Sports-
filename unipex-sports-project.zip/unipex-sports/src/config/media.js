/**
 * Image registry. Drop real photographs into /public/images and set `src`
 * (for example '/images/hero.jpg'). While `src` is empty a labelled
 * pitch-marking placeholder renders, so no slot is ever broken or blank.
 * Use real store photographs only.
 *
 * `alt` is used once a real image is set. `label` names the slot while empty.
 * `pitch` picks the placeholder marking: centre | box | corner | halfway | arc
 * `width`/`height` (optional) reserve space and avoid layout shift.
 */
export const media = {
  hero: {
    src: '',
    alt: 'Football player in a jersey under stadium lights',
    label: 'Hero photograph',
    pitch: 'centre',
  },

  collections: {
    jerseys: { src: '', alt: 'Football jerseys on display', label: 'Football jerseys', pitch: 'box' },
    cricket: { src: '', alt: 'Cricket bats and balls', label: 'Cricket', pitch: 'halfway' },
    equipment: {
      src: '',
      alt: 'Footballs, volleyballs and badminton rackets',
      label: 'Sports equipment',
      pitch: 'arc',
    },
    sportswear: { src: '', alt: 'Sports shoes and training apparel', label: 'Sportswear', pitch: 'corner' },
    custom: { src: '', alt: 'Custom printed jersey', label: 'Custom jerseys', pitch: 'centre' },
  },

  customClosups: [
    { src: '', alt: 'Close-up of a printed player name on a jersey', label: 'Name print close-up', pitch: 'halfway' },
    { src: '', alt: 'Close-up of a printed number on a jersey', label: 'Number print close-up', pitch: 'arc' },
  ],

  about: {
    src: '',
    alt: "Unipex Sports store front on Peter's Road, Royapettah",
    label: 'Store photograph',
    pitch: 'box',
  },

  /** `span` controls the grid footprint: lg | tall | wide | sm */
  gallery: [
    { src: '', alt: 'Unipex Sports store exterior', label: 'Store exterior', pitch: 'box', span: 'lg' },
    { src: '', alt: 'Inside the Unipex Sports store', label: 'Store interior', pitch: 'halfway', span: 'sm' },
    { src: '', alt: 'Wall of football jerseys', label: 'Jersey wall', pitch: 'corner', span: 'tall' },
    { src: '', alt: 'Sports merchandise on display', label: 'Merchandise', pitch: 'arc', span: 'sm' },
    { src: '', alt: 'Sports equipment shelves', label: 'Equipment', pitch: 'centre', span: 'wide' },
    { src: '', alt: 'Product display at the counter', label: 'Product displays', pitch: 'halfway', span: 'sm' },
  ],
}
