/**
 * Business facts. Everything here is shown on the site and in structured data.
 * Update this file only; no component hardcodes contact details.
 *
 * `verify` lists facts that came from the brief or a business listing and
 * should be confirmed with the shop before the site goes live.
 */
export const site = {
  name: 'Unipex Sports',
  tagline: 'GEAR UP. SHOW UP. PLAY HARD.',
  alternateHeadline: 'FOR THE LOVE OF THE GAME.',
  category: 'Sports goods store',
  founded: { year: 2012, show: true },
  phone: { display: '+91 97517 73713', e164: '+919751773713', whatsappNumber: '919751773713' },
  address: {
    lines: ["89/63, Peter's Road", 'Royapettah', 'Chennai, Tamil Nadu 600014'],
    street: "89/63, Peter's Road",
    locality: 'Royapettah, Chennai',
    region: 'Tamil Nadu',
    postalCode: '600014',
    country: 'IN',
    landmark: 'Opposite Bharat Scans',
  },
  hours: {
    label: 'Monday to Sunday',
    open: '10:00 AM',
    close: '9:00 PM',
    // schema.org format
    schema: {
      days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
      opens: '10:00',
      closes: '21:00',
    },
  },
  maps: {
    // The short link supplied with the brief: opens the live listing, reviews and photos.
    listingUrl: 'https://maps.app.goo.gl/Z3z59qycQFFWsasU8',
    directionsUrl:
      'https://www.google.com/maps/dir/?api=1&destination=Unipex+Sports%2C+89%2F63+Peter%27s+Rd%2C+Royapettah%2C+Chennai+600014',
    embedUrl:
      'https://www.google.com/maps?q=Unipex+Sports%2C+89%2F63+Peter%27s+Rd%2C+Royapettah%2C+Chennai+600014&output=embed',
  },
  rating: { value: 4.7, count: 402, source: 'Google Maps' },
  /** Add real, verified profile URLs here as { label, href, icon }. Nothing renders while this is empty. */
  socials: [],
  verify: ['Opening hours', 'Year established (2012)', 'Google rating and review count'],
}

export const whatsappMessages = {
  general: 'Hello Unipex Sports! I would like to know more about your available jerseys and sports products.',
  custom: 'Hello Unipex Sports! I would like to enquire about a custom jersey.',
  category: (name) => `Hello Unipex Sports! I would like to know more about your ${name}.`,
  search: (term) => `Hello Unipex Sports! I am looking for: ${term}. Is it available?`,
}
