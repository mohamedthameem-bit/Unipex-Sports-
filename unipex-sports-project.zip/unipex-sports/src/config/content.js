/**
 * Page copy and catalogue structure. No prices, stock or specifications:
 * items are category names only until real inventory is supplied.
 */
export const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Jerseys', href: '#jerseys' },
  { label: 'Sports Equipment', href: '#equipment' },
  { label: 'About Us', href: '#about' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Contact', href: '#contact' },
]

export const hero = {
  headline: ['BUILT FOR', 'THE GAME.'],
  text: 'From match-day jerseys to everyday sports essentials. Find your gear, represent your team and bring your passion to the game.',
  primaryCta: { label: 'Explore collection', href: '#collections' },
  secondaryCta: { label: 'Visit our store', href: '#contact' },
  marquee: 'YOUR GAME. YOUR STYLE. YOUR GEAR.',
}

export const collections = {
  heading: 'FIND YOUR GAME.',
  text: 'Everything you need to represent your team and perform your best.',
  exploreLabel: 'Explore',
  /**
   * `layout` drives the editorial grid placement in Collections.jsx:
   * feature | offset | wide | standard | custom
   * `anchor` is the in-page id of the block (nav and search scroll to it).
   * `exploreHref` overrides the default WhatsApp enquiry for the Explore button.
   */
  categories: [
    {
      id: 'jerseys',
      anchor: 'jerseys',
      name: 'Football Jerseys',
      description: 'The shirt you will wear to the match, the ground or the street.',
      items: [
        'Club jerseys',
        'National team jerseys',
        'Retro football jerseys',
        'Home and away kits',
        'Fan jerseys',
        'Player-style jerseys',
      ],
      layout: 'feature',
    },
    {
      id: 'cricket',
      anchor: 'cricket',
      name: 'Cricket',
      description: 'Bats, balls and kit for net sessions and match days.',
      items: ['Cricket bats', 'Cricket balls', 'Cricket accessories', 'Cricket uniforms'],
      layout: 'offset',
    },
    {
      id: 'equipment',
      anchor: 'equipment',
      name: 'Sports Equipment',
      description: 'Balls, rackets and training gear for the game you play.',
      items: ['Footballs', 'Volleyballs', 'Badminton rackets', 'Training equipment', 'Sports accessories'],
      layout: 'wide',
    },
    {
      id: 'sportswear',
      anchor: 'sportswear',
      name: 'Sportswear',
      description: 'What you train, play and travel in.',
      items: ['Sports shoes', 'Training apparel', 'Sports uniforms', 'Teamwear'],
      layout: 'standard',
    },
    {
      id: 'custom',
      anchor: 'custom-range',
      name: 'Custom Jerseys',
      description: 'Your name and number on your jersey.',
      items: ['Name printing', 'Number printing', 'Custom jersey requests'],
      layout: 'custom',
      exploreHref: '#custom',
    },
  ],
}

export const customJersey = {
  heading: 'MAKE IT YOURS.',
  text: 'Your name. Your number. Your colours. Make your jersey uniquely yours.',
  previewNote:
    'Preview only. Printing options, colours, prices and turnaround are confirmed by the store when you enquire.',
  cta: 'Enquire for customization',
  fields: { name: 'Name on the back', number: 'Number', colour: 'Jersey colour', style: 'Style' },
  limits: { nameMax: 12, numberMax: 2 },
  defaults: { name: 'UNIPEX', number: '10', colour: 'black', style: 'plain' },
  colours: [
    { id: 'black', label: 'Black', base: '#101010', accent: '#C7F000' },
    { id: 'white', label: 'White', base: '#F5F3ED', accent: '#101010' },
    { id: 'lime', label: 'Lime', base: '#C7F000', accent: '#101010' },
    { id: 'blue', label: 'Royal blue', base: '#1F4FD8', accent: '#F5F3ED' },
    { id: 'red', label: 'Red', base: '#C8202F', accent: '#F5F3ED' },
    { id: 'amber', label: 'Amber', base: '#F2A900', accent: '#101010' },
  ],
  styles: [
    { id: 'plain', label: 'Plain' },
    { id: 'stripes', label: 'Stripes' },
    { id: 'bands', label: 'Hem bands' },
  ],
}

export const about = {
  heading: 'MORE THAN JUST SPORTS GEAR.',
  paragraphs: [
    'Unipex Sports is a sports retail destination in Royapettah, Chennai, bringing together sports enthusiasts and players with a wide selection of sportswear, football jerseys and sporting equipment.',
    "Whether you're looking for your favourite team's jersey, sports accessories or equipment for your next game, discover your sporting essentials at Unipex Sports.",
  ],
  facts: [
    { term: 'Location', detail: 'Royapettah, Chennai' },
    { term: 'Football', detail: 'Jerseys and sports merchandise' },
    { term: 'Equipment', detail: 'Sports equipment and accessories' },
  ],
}

export const reviews = {
  heading: 'THE GAME SPEAKS. OUR CUSTOMERS DO TOO.',
  cta: 'Read all Google reviews',
  themesIntro: 'What customers talk about',
  /** Themes seen in customer feedback on the listing. These are topics, not quotes. */
  themes: [
    'An extensive football jersey collection',
    'Retro and classic jerseys',
    'Quality fabric and stitching',
    'Name and number customization',
    'Helpful, knowledgeable staff',
    'Reasonable pricing',
    'A wide variety of sports equipment',
  ],
  /**
   * Genuine reviews only, copied from the Google listing with permission.
   * Shape: { author, text, date? }. Leave empty rather than inventing any.
   */
  quotes: [],
}

export const gallery = {
  heading: 'STEP INSIDE UNIPEX.',
}

export const visit = {
  heading: 'YOUR NEXT GAME STARTS HERE.',
  directions: 'Get directions',
  call: 'Call now',
  whatsapp: 'WhatsApp us',
}

export const footer = {
  links: [
    { label: 'Home', href: '#home' },
    { label: 'Jerseys', href: '#jerseys' },
    { label: 'Sports Equipment', href: '#equipment' },
    { label: 'About', href: '#about' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Contact', href: '#contact' },
  ],
  copyright: '© 2026 Unipex Sports. All Rights Reserved.',
}
