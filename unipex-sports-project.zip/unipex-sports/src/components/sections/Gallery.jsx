import { Media } from '../ui/Media'
import { gallery } from '../../config/content'
import { media } from '../../config/media'

/** Grid footprint per `span` keyword in config/media.js. Six columns on desktop. */
const spans = {
  lg: 'col-span-2 aspect-[4/3] lg:col-span-4 lg:row-span-2 lg:aspect-auto',
  tall: 'col-span-1 aspect-[3/4] lg:col-span-2 lg:row-span-2 lg:aspect-auto',
  wide: 'col-span-2 aspect-[16/9] lg:col-span-4 lg:aspect-auto',
  sm: 'col-span-1 aspect-square lg:col-span-2 lg:aspect-auto',
}

export function Gallery() {
  return (
    <section id="gallery" aria-labelledby="gallery-heading" className="grain bg-pitch py-20 sm:py-28">
      <div className="relative z-10 mx-auto max-w-[1600px] px-5 sm:px-8">
        <h2 id="gallery-heading" className="display text-[clamp(4rem,12vw,11rem)]">
          {gallery.heading}
        </h2>

        <div className="mt-12 grid grid-cols-2 gap-3 sm:gap-4 lg:auto-rows-[17rem] lg:grid-cols-6">
          {media.gallery.map((item) => (
            <figure key={item.label} className={`relative m-0 ${spans[item.span]}`}>
              <Media item={item} className="h-full w-full" sizes="(min-width:1024px) 40vw, 50vw" />
              <figcaption className="pointer-events-none absolute left-0 top-0 z-10 bg-pitch px-3 py-1.5 text-xs font-bold">
                {item.label}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
