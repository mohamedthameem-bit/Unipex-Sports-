import { Clock, MapPin, Navigation, Phone } from 'lucide-react'
import { Button } from '../ui/Button'
import { WhatsAppIcon } from '../ui/WhatsAppIcon'
import { visit } from '../../config/content'
import { site, whatsappMessages } from '../../config/site'
import { telUrl, whatsappUrl } from '../../lib/links'

const rowIcon = 'mt-1 shrink-0'

export function VisitStore() {
  const { address, hours, phone, maps } = site

  return (
    <section id="contact" aria-labelledby="contact-heading" className="on-light bg-lime py-20 text-pitch sm:py-28">
      <div className="mx-auto grid max-w-[1600px] gap-12 px-5 sm:px-8 lg:grid-cols-12 lg:gap-14">
        <div className="lg:col-span-6">
          <h2 id="contact-heading" className="display text-[clamp(3.8rem,9vw,8.5rem)]">
            {visit.heading}
          </h2>

          <address className="mt-10 grid max-w-xl gap-5 not-italic">
            <p className="flex gap-3 text-lg font-bold">
              <MapPin className={rowIcon} size={22} aria-hidden="true" />
              <span>
                {address.lines.map((line) => (
                  <span key={line} className="block">
                    {line}
                  </span>
                ))}
                <span className="mt-1 block font-semibold text-pitch/75">{address.landmark}</span>
              </span>
            </p>
            <p className="flex gap-3 text-lg font-bold">
              <Clock className={rowIcon} size={22} aria-hidden="true" />
              <span>
                {hours.label}
                <span className="block">
                  {hours.open} to {hours.close}
                </span>
              </span>
            </p>
            <p className="flex gap-3 text-lg font-bold">
              <Phone className={rowIcon} size={22} aria-hidden="true" />
              <a href={telUrl} className="link-draw">
                {phone.display}
              </a>
            </p>
          </address>

          <div className="mt-10 flex flex-wrap gap-3">
            <Button href={maps.directionsUrl} external variant="dark">
              <Navigation size={18} /> {visit.directions}
            </Button>
            <Button href={telUrl} variant="outlineDark">
              <Phone size={18} /> {visit.call}
            </Button>
            <Button href={whatsappUrl(whatsappMessages.general)} external variant="outlineDark">
              <WhatsAppIcon size={18} /> {visit.whatsapp}
            </Button>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="h-full min-h-[22rem] border-2 border-pitch bg-stadium lg:min-h-[34rem]">
            <iframe
              title="Unipex Sports on Google Maps"
              src={maps.embedUrl}
              className="h-full min-h-[22rem] w-full border-0 lg:min-h-[34rem]"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
          </div>
        </div>
      </div>
    </section>
  )
}
