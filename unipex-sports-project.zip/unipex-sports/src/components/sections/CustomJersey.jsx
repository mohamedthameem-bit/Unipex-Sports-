import { useMemo, useState } from 'react'
import { Button } from '../ui/Button'
import { Media } from '../ui/Media'
import { PitchMarking } from '../ui/PitchMarking'
import { WhatsAppIcon } from '../ui/WhatsAppIcon'
import { JerseyPreview } from '../custom/JerseyPreview'
import { customJersey as copy } from '../../config/content'
import { media } from '../../config/media'
import { whatsappUrl } from '../../lib/links'
import { customJerseyMessage } from '../../lib/messages'

const cleanName = (v) => v.toUpperCase().replace(/[^A-Z0-9 .'-]/g, '').slice(0, copy.limits.nameMax)
const cleanNumber = (v) => v.replace(/\D/g, '').slice(0, copy.limits.numberMax)

const fieldLabel = 'mb-2 block text-sm font-bold text-stadium'
const textInput =
  'display w-full border-2 border-stadium/40 bg-transparent px-4 py-3 text-3xl text-stadium placeholder:text-stadium/30 transition-colors focus:border-lime focus:outline-none'

export function CustomJersey() {
  const [name, setName] = useState(copy.defaults.name)
  const [number, setNumber] = useState(copy.defaults.number)
  const [colourId, setColourId] = useState(copy.defaults.colour)
  const [styleId, setStyleId] = useState(copy.defaults.style)

  const colour = copy.colours.find((c) => c.id === colourId) ?? copy.colours[0]
  const enquiryUrl = useMemo(
    () => whatsappUrl(customJerseyMessage({ name, number, colourId, styleId })),
    [name, number, colourId, styleId],
  )

  return (
    <section id="custom" aria-labelledby="custom-heading" className="grain bg-pitch py-20 sm:py-28">
      <div className="relative z-10 mx-auto grid max-w-[1600px] gap-12 px-5 sm:px-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <h2 id="custom-heading" className="display text-[clamp(4.5rem,13vw,10.5rem)]">
            {copy.heading}
          </h2>
          <p className="mt-6 max-w-md text-lg text-stadium/80">{copy.text}</p>

          <div className="mt-10 grid grid-cols-[1fr_6.5rem] gap-4">
            <div>
              <label htmlFor="jersey-name" className={fieldLabel}>
                {copy.fields.name}
              </label>
              <input
                id="jersey-name"
                value={name}
                onChange={(e) => setName(cleanName(e.target.value))}
                maxLength={copy.limits.nameMax}
                autoComplete="off"
                spellCheck={false}
                className={textInput}
              />
            </div>
            <div>
              <label htmlFor="jersey-number" className={fieldLabel}>
                {copy.fields.number}
              </label>
              <input
                id="jersey-number"
                value={number}
                onChange={(e) => setNumber(cleanNumber(e.target.value))}
                inputMode="numeric"
                maxLength={copy.limits.numberMax}
                autoComplete="off"
                className={`${textInput} text-center`}
              />
            </div>
          </div>

          <fieldset className="mt-6">
            <legend className={fieldLabel}>
              {copy.fields.colour}: <span className="font-semibold text-stadium/70">{colour.label}</span>
            </legend>
            <div className="flex flex-wrap gap-3">
              {copy.colours.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setColourId(c.id)}
                  aria-pressed={c.id === colourId}
                  aria-label={c.label}
                  title={c.label}
                  style={{ backgroundColor: c.base }}
                  className={`h-11 w-11 border-2 transition-transform hover:-translate-y-0.5 ${
                    c.id === colourId ? 'border-lime outline outline-2 outline-offset-2 outline-lime' : 'border-stadium/30'
                  }`}
                />
              ))}
            </div>
          </fieldset>

          <fieldset className="mt-6">
            <legend className={fieldLabel}>{copy.fields.style}</legend>
            <div className="flex flex-wrap gap-2">
              {copy.styles.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setStyleId(s.id)}
                  aria-pressed={s.id === styleId}
                  className={`border-2 px-4 py-2 text-sm font-bold transition-colors ${
                    s.id === styleId
                      ? 'border-lime bg-lime text-pitch'
                      : 'border-stadium/40 text-stadium hover:border-stadium'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </fieldset>

          <div className="mt-10">
            <Button href={enquiryUrl} external variant="lime">
              <WhatsAppIcon size={20} /> {copy.cta}
            </Button>
            <p className="mt-4 max-w-md text-sm text-stadium/60">{copy.previewNote}</p>
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="relative grid place-items-center overflow-hidden bg-graphite px-6 py-10 sm:py-14">
            <PitchMarking
              variant="centre"
              className="pointer-events-none absolute inset-0 h-full w-full text-stadium/[0.07]"
            />
            <JerseyPreview
              name={name}
              number={number}
              base={colour.base}
              accent={colour.accent}
              styleId={styleId}
              className="relative w-full max-w-[30rem] drop-shadow-[0_24px_30px_rgba(0,0,0,0.45)]"
            />
          </div>
          <div className="mt-4 grid grid-cols-2 gap-4">
            {media.customClosups.map((item) => (
              <Media key={item.label} item={item} className="aspect-[4/3]" sizes="(min-width:1024px) 28vw, 45vw" />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
