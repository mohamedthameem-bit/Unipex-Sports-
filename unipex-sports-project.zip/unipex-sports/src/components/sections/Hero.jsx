import { motion, useReducedMotion } from 'framer-motion'
import { Button } from '../ui/Button'
import { Marquee } from '../ui/Marquee'
import { Media } from '../ui/Media'
import { hero } from '../../config/content'
import { media } from '../../config/media'

const EASE = [0.2, 0.7, 0.2, 1]

/** One headline line that rises out of a mask. This is the page's single orchestrated entrance. */
function Line({ children, index, reduce }) {
  return (
    <span className="block overflow-hidden pb-[0.04em]">
      <motion.span
        className="block"
        initial={reduce ? false : { y: '105%' }}
        animate={{ y: 0 }}
        transition={{ duration: 0.8, delay: 0.15 + index * 0.12, ease: EASE }}
      >
        {children}
      </motion.span>
    </span>
  )
}

export function Hero() {
  const reduce = useReducedMotion()

  return (
    <section
      id="home"
      aria-labelledby="hero-heading"
      className="grain relative flex min-h-[100svh] flex-col overflow-hidden bg-pitch"
    >
      <Media
        item={media.hero}
        priority
        reveal={false}
        sizes="(min-width:1024px) 46vw, 100vw"
        className="absolute inset-x-0 top-[4.5rem] h-[34svh] lg:inset-y-0 lg:left-auto lg:right-0 lg:top-0 lg:h-auto lg:w-[46%]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-gradient-to-t from-pitch via-pitch/10 to-transparent lg:bg-gradient-to-r lg:from-pitch lg:via-transparent lg:to-transparent"
      />

      <div className="relative z-10 mx-auto flex w-full max-w-[1600px] flex-1 flex-col justify-end px-5 pb-24 pt-[calc(4.5rem+34svh)] sm:px-8 sm:pb-28 lg:pt-32">
        <h1
          id="hero-heading"
          className="display text-[clamp(4.6rem,21vw,8.5rem)] sm:text-[clamp(7rem,19vw,13rem)] lg:text-[clamp(9rem,15.5vw,17.5rem)]"
        >
          {hero.headline.map((line, i) => (
            <Line key={line} index={i} reduce={reduce}>
              {line}
            </Line>
          ))}
        </h1>

        <motion.div
          className="mt-6 max-w-xl sm:mt-8"
          initial={reduce ? false : { opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6, ease: EASE }}
        >
          <p className="text-base text-stadium/85 sm:text-lg">{hero.text}</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Button href={hero.primaryCta.href} variant="lime">
              {hero.primaryCta.label}
            </Button>
            <Button href={hero.secondaryCta.href} variant="ghost">
              {hero.secondaryCta.label}
            </Button>
          </div>
        </motion.div>
      </div>

      <Marquee text={hero.marquee} className="absolute inset-x-0 bottom-0 z-20 bg-lime py-2.5 text-pitch" />
    </section>
  )
}
