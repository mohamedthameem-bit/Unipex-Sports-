import { Media } from '../ui/Media'
import { about } from '../../config/content'
import { media } from '../../config/media'
import { site } from '../../config/site'

export function About() {
  const facts = [
    ...(site.founded.show ? [{ term: 'Since', detail: String(site.founded.year) }] : []),
    ...about.facts,
  ]

  return (
    <section id="about" aria-labelledby="about-heading" className="grain bg-graphite py-20 sm:py-28">
      <div className="relative z-10 mx-auto grid max-w-[1600px] gap-12 px-5 sm:px-8 lg:grid-cols-12 lg:gap-16">
        <Media
          item={media.about}
          className="aspect-[4/5] lg:col-span-6 lg:aspect-auto lg:min-h-[44rem]"
          sizes="(min-width:1024px) 50vw, 100vw"
        />
        <div className="flex flex-col justify-center lg:col-span-6">
          <h2 id="about-heading" className="display text-[clamp(3.6rem,8vw,8rem)]">
            {about.heading}
          </h2>
          <div className="mt-8 max-w-xl space-y-5 text-lg text-stadium/85">
            {about.paragraphs.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>
          <dl className="mt-10 max-w-xl border-t-2 border-lime">
            {facts.map((fact) => (
              <div key={fact.term} className="grid grid-cols-[7rem_1fr] gap-4 border-b border-stadium/15 py-3">
                <dt className="font-bold text-stadium/60">{fact.term}</dt>
                <dd className="font-bold">{fact.detail}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}
