import { Button } from '../ui/Button'
import { Media } from '../ui/Media'
import { WhatsAppIcon } from '../ui/WhatsAppIcon'
import { collections } from '../../config/content'
import { media } from '../../config/media'
import { whatsappMessages } from '../../config/site'
import { whatsappUrl } from '../../lib/links'

/**
 * Grid placement and image proportions per layout keyword in config.
 * Different footprints and offsets keep the section editorial, not a card grid.
 */
const layouts = {
  feature: { cell: 'lg:col-span-7', image: 'aspect-[4/5] sm:aspect-[5/4] lg:aspect-[4/5]', title: 'text-[clamp(3.2rem,7vw,6.5rem)]' },
  offset: { cell: 'lg:col-span-5 lg:mt-36', image: 'aspect-square', title: 'text-[clamp(3rem,5vw,4.8rem)]' },
  wide: { cell: 'lg:col-span-8', image: 'aspect-[4/3] sm:aspect-[16/9]', title: 'text-[clamp(3rem,5.5vw,5.2rem)]' },
  standard: { cell: 'lg:col-span-4 lg:mt-24', image: 'aspect-[3/4]', title: 'text-[clamp(2.8rem,4.2vw,4rem)]' },
}

function CategoryBlock({ category }) {
  const layout = layouts[category.layout]
  const href = category.exploreHref ?? whatsappUrl(whatsappMessages.category(category.name.toLowerCase()))
  const external = !category.exploreHref

  return (
    <article id={category.anchor} className={layout.cell}>
      <Media
        item={media.collections[category.id]}
        tone="light"
        className={layout.image}
        sizes="(min-width:1024px) 55vw, 100vw"
      />
      <div className="mt-5 grid gap-x-8 gap-y-4 sm:grid-cols-[1fr_auto] sm:items-end">
        <div>
          <h3 className={`display ${layout.title}`}>{category.name}</h3>
          <p className="mt-2 max-w-md text-pitch/75">{category.description}</p>
        </div>
        <Button href={href} external={external} variant="outlineDark" aria-label={`${collections.exploreLabel} ${category.name}`}>
          {collections.exploreLabel}
          {external && <WhatsAppIcon size={17} />}
        </Button>
      </div>
      <ul className="mt-5 grid grid-cols-2 gap-x-6 gap-y-1 border-t-2 border-pitch pt-4 text-sm font-bold sm:grid-cols-3">
        {category.items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </article>
  )
}

function CustomBlock({ category }) {
  return (
    <article id={category.anchor} className="mt-20 grid bg-pitch text-stadium lg:col-span-12 lg:mt-28 lg:grid-cols-12">
      <Media
        item={media.collections.custom}
        className="aspect-[4/3] lg:col-span-5 lg:aspect-auto lg:min-h-[26rem]"
        sizes="(min-width:1024px) 40vw, 100vw"
      />
      <div className="flex flex-col justify-center gap-6 p-6 sm:p-10 lg:col-span-7 lg:p-14">
        <h3 className="display text-[clamp(3.2rem,7vw,6.5rem)]">{category.name}</h3>
        <p className="max-w-md text-lg text-stadium/80">{category.description}</p>
        <ul className="grid max-w-md gap-1 border-t-2 border-lime pt-4 font-bold sm:grid-cols-3">
          {category.items.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
        <div>
          <Button href={category.exploreHref} variant="lime">
            Design yours
          </Button>
        </div>
      </div>
    </article>
  )
}

export function Collections() {
  const { categories } = collections
  const custom = categories.find((c) => c.layout === 'custom')

  return (
    <section
      id="collections"
      aria-labelledby="collections-heading"
      className="on-light bg-stadium py-20 text-pitch sm:py-28"
    >
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8">
        <div className="grid items-end gap-6 lg:grid-cols-12">
          <h2 id="collections-heading" className="display text-[clamp(4.5rem,14vw,12.5rem)] lg:col-span-8">
            {collections.heading}
          </h2>
          <p className="max-w-sm text-lg text-pitch/75 lg:col-span-4 lg:pb-4">{collections.text}</p>
        </div>

        <div className="mt-14 grid gap-x-8 gap-y-16 lg:mt-20 lg:grid-cols-12 lg:gap-y-20">
          {categories
            .filter((c) => c.layout !== 'custom')
            .map((category) => (
              <CategoryBlock key={category.id} category={category} />
            ))}
          {custom && <CustomBlock category={custom} />}
        </div>
      </div>
    </section>
  )
}
