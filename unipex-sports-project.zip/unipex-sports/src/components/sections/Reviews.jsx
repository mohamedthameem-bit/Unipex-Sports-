import { Button } from '../ui/Button'
import { Stars } from '../ui/Stars'
import { reviews } from '../../config/content'
import { site } from '../../config/site'

export function Reviews() {
  const { rating } = site
  const hasQuotes = reviews.quotes.length > 0

  return (
    <section id="reviews" aria-labelledby="reviews-heading" className="on-light bg-stadium py-20 text-pitch sm:py-28">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8">
        <h2 id="reviews-heading" className="display max-w-6xl text-[clamp(3.4rem,9.5vw,9rem)]">
          {reviews.heading}
        </h2>

        <div className="mt-14 grid gap-12 lg:mt-20 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5">
            <p className="display text-[clamp(8rem,22vw,17rem)] leading-[0.8]">{rating.value}</p>
            <Stars value={rating.value} size={30} className="mt-6" />
            <p className="mt-3 text-lg font-bold">
              {rating.count} reviews on {rating.source}
            </p>
            <div className="mt-8">
              <Button href={site.maps.listingUrl} external variant="dark">
                {reviews.cta}
              </Button>
            </div>
          </div>

          <div className="lg:col-span-7">
            {hasQuotes ? (
              <ul className="divide-y-2 divide-pitch">
                {reviews.quotes.map((quote) => (
                  <li key={`${quote.author}-${quote.text.slice(0, 24)}`} className="py-8 first:pt-0">
                    <blockquote className="display text-[clamp(1.8rem,3.4vw,3rem)] normal-case leading-[1.05]">
                      {quote.text}
                    </blockquote>
                    <p className="mt-3 font-bold">
                      {quote.author}
                      {quote.date ? `, ${quote.date}` : ''}
                    </p>
                  </li>
                ))}
              </ul>
            ) : (
              <>
                <p className="font-bold text-pitch/70">{reviews.themesIntro}</p>
                <ul className="mt-3 border-t-2 border-pitch">
                  {reviews.themes.map((theme) => (
                    <li
                      key={theme}
                      className="display border-b-2 border-pitch py-3 text-[clamp(1.7rem,3.4vw,3rem)] leading-none"
                    >
                      {theme}
                    </li>
                  ))}
                </ul>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
