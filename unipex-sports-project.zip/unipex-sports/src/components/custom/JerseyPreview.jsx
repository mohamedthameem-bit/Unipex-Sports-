import { useId } from 'react'
import { shade } from '../../lib/color'

const BODY =
  'M160 28 L100 48 L30 120 L28 128 L76 172 L96 150 L96 410 Q96 420 106 420 L294 420 Q304 420 304 410 L304 150 L324 172 L372 128 L370 120 L300 48 L240 28 Q200 62 160 28 Z'

/** Fits the name on one line: shrinks as the name gets longer. */
const nameSize = (length) => Math.min(34, 170 / (0.46 * Math.max(length, 1)))

/**
 * Back-of-jersey mockup with live name and number. Pure illustration:
 * not a product photo and not a statement of what the shop can print.
 */
export function JerseyPreview({ name, number, base, accent, styleId, className = '' }) {
  const uid = useId().replace(/:/g, '')
  const seam = shade(base, -0.28)

  return (
    <svg
      viewBox="0 0 400 450"
      role="img"
      aria-label={`Jersey preview showing ${name || 'no name'} and number ${number || 'none'}`}
      className={className}
    >
      <defs>
        <clipPath id={`${uid}-body`}>
          <path d={BODY} />
        </clipPath>
        <linearGradient id={`${uid}-shade`} x1="0" x2="1" y1="0" y2="0">
          <stop offset="0" stopColor="#000" stopOpacity="0.22" />
          <stop offset="0.22" stopColor="#000" stopOpacity="0" />
          <stop offset="0.78" stopColor="#000" stopOpacity="0" />
          <stop offset="1" stopColor="#000" stopOpacity="0.22" />
        </linearGradient>
        <pattern id={`${uid}-fabric`} width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="2.5" height="6" fill="#000" opacity="0.06" />
        </pattern>
      </defs>

      <ellipse cx="200" cy="438" rx="120" ry="6" fill="#000" opacity="0.35" />

      <g clipPath={`url(#${uid}-body)`}>
        <rect width="400" height="450" fill={base} />

        {styleId === 'stripes' &&
          Array.from({ length: 14 }).map((_, i) => (
            <rect key={i} x={20 + i * 28} y="0" width="13" height="450" fill={accent} opacity="0.2" />
          ))}

        {styleId === 'bands' && (
          <>
            <rect x="0" y="334" width="400" height="22" fill={accent} />
            <rect x="0" y="372" width="400" height="22" fill={accent} />
          </>
        )}

        <rect width="400" height="450" fill={`url(#${uid}-fabric)`} />
        <rect width="400" height="450" fill={`url(#${uid}-shade)`} />
        {/* hem */}
        <rect x="90" y="408" width="220" height="14" fill={seam} opacity="0.55" />
      </g>

      {/* seams */}
      <path d="M96 150 L96 408 M304 150 L304 408" stroke={seam} strokeWidth="1.5" opacity="0.7" fill="none" />
      <path d="M160 28 L96 150 M240 28 L304 150" stroke={seam} strokeWidth="1.5" opacity="0.5" fill="none" />

      {/* collar and cuffs */}
      <path d="M160 28 Q200 62 240 28" stroke={accent} strokeWidth="9" strokeLinecap="round" fill="none" />
      <path d="M31 132 L79 176" stroke={accent} strokeWidth="9" strokeLinecap="butt" />
      <path d="M369 132 L321 176" stroke={accent} strokeWidth="9" strokeLinecap="butt" />

      {/* printing */}
      {name && (
        <text
          x="200"
          y="118"
          textAnchor="middle"
          fill={accent}
          fontFamily="Anton, Impact, sans-serif"
          fontSize={nameSize(name.length)}
          letterSpacing="2"
        >
          {name}
        </text>
      )}
      {number && (
        <text
          x="200"
          y="268"
          textAnchor="middle"
          fill={accent}
          fontFamily="Anton, Impact, sans-serif"
          fontSize={number.length > 1 ? 150 : 170}
        >
          {number}
        </text>
      )}
    </svg>
  )
}
