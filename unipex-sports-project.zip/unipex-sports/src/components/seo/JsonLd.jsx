import { site } from '../../config/site'

/** schema.org SportingGoodsStore data generated from config/site.js. */
export function JsonLd() {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'SportingGoodsStore',
    name: site.name,
    description: 'Football jerseys, sportswear and sports equipment in Royapettah, Chennai.',
    telephone: site.phone.e164,
    hasMap: site.maps.listingUrl,
    address: {
      '@type': 'PostalAddress',
      streetAddress: site.address.street,
      addressLocality: 'Chennai',
      addressRegion: site.address.region,
      postalCode: site.address.postalCode,
      addressCountry: site.address.country,
    },
    openingHoursSpecification: [
      {
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: site.hours.schema.days,
        opens: site.hours.schema.opens,
        closes: site.hours.schema.closes,
      },
    ],
    ...(site.socials.length ? { sameAs: site.socials.map((s) => s.href) } : {}),
  }
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />
}
