/**
 * UNIPEX SPORTS wordmark. Set in the display face; the lime bar under
 * SPORTS references a touchline. Pure type, no emblem.
 */
export function Wordmark({ className = '', size = 'md' }) {
  const sizes = {
    md: { word: 'text-[1.7rem]', sub: 'text-[0.62rem] tracking-[0.42em]' },
    lg: { word: 'text-4xl', sub: 'text-xs tracking-[0.5em]' },
  }[size]
  return (
    <span className={`inline-flex flex-col leading-none ${className}`}>
      <span className={`display ${sizes.word} text-stadium`}>UNIPEX</span>
      <span className={`mt-1 inline-flex items-center gap-2 font-display ${sizes.sub} text-stadium`}>
        SPORTS
        <span aria-hidden="true" className="h-[3px] flex-1 bg-lime" />
      </span>
    </span>
  )
}
