import { motion, useReducedMotion } from 'framer-motion'
import { PitchMarking } from './PitchMarking'

/**
 * A photograph slot driven by an entry from config/media.js.
 * - With `src`: renders an optimised <img> (lazy unless `priority`).
 * - Without `src`: renders a labelled pitch-marking placeholder, never a
 *   broken image.
 * The frame reveals once with a clip wipe; hover zooms the image slightly.
 * Size the frame through `className` (aspect ratio, height, grid span).
 */
export function Media({ item, className = '', priority = false, sizes, reveal = true, tone = 'dark' }) {
  const reduce = useReducedMotion()
  const animate = reveal && !reduce

  const frameTone =
    tone === 'light' ? 'bg-[#e6e3da] text-pitch/25' : 'bg-graphite text-stadium/15'
  const captionTone = tone === 'light' ? 'text-pitch/70' : 'text-stadium/70'

  const content = item.src ? (
    <img
      src={item.src}
      alt={item.alt}
      width={item.width}
      height={item.height}
      sizes={sizes}
      loading={priority ? 'eager' : 'lazy'}
      fetchPriority={priority ? 'high' : 'auto'}
      decoding="async"
      className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover/media:scale-[1.04]"
    />
  ) : (
    <div role="img" aria-label={`${item.label}: photograph to be added`} className="relative h-full w-full">
      <PitchMarking
        variant={item.pitch}
        className="absolute inset-0 h-full w-full transition-transform duration-700 ease-out group-hover/media:scale-[1.04]"
      />
      <p className={`absolute bottom-3 left-4 right-4 text-xs font-semibold ${captionTone}`}>
        Photo: {item.label}
      </p>
    </div>
  )

  const base = `group/media relative overflow-hidden ${frameTone} ${className}`

  if (!animate) return <div className={base}>{content}</div>

  return (
    <motion.div
      className={base}
      initial={{ clipPath: 'inset(0 0 100% 0)' }}
      whileInView={{ clipPath: 'inset(0 0 0% 0)' }}
      viewport={{ once: true, margin: '0px 0px -12% 0px' }}
      transition={{ duration: 0.75, ease: [0.2, 0.7, 0.2, 1] }}
    >
      {content}
    </motion.div>
  )
}
