import { forwardRef } from 'react'

const variants = {
  lime: 'btn-lime',
  light: 'btn-light',
  ghost: 'btn-ghost',
  dark: 'btn-dark',
  outlineDark: 'btn-outline-dark',
}

/**
 * Renders an <a> when `href` is given, otherwise a <button>.
 * External links open safely in a new tab.
 */
export const Button = forwardRef(function Button(
  { href, variant = 'lime', external = false, className = '', children, ...rest },
  ref,
) {
  const classes = `btn ${variants[variant]} ${className}`.trim()
  if (href) {
    const externalProps = external ? { target: '_blank', rel: 'noopener noreferrer' } : {}
    return (
      <a ref={ref} href={href} className={classes} {...externalProps} {...rest}>
        {children}
      </a>
    )
  }
  return (
    <button ref={ref} type="button" className={classes} {...rest}>
      {children}
    </button>
  )
})
