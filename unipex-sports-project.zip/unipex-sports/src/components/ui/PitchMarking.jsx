/**
 * Football pitch line drawings used as the visual language of empty
 * photo slots. Strokes use currentColor.
 */
const drawings = {
  centre: (
    <>
      <rect x="20" y="20" width="360" height="260" />
      <line x1="200" y1="20" x2="200" y2="280" />
      <circle cx="200" cy="150" r="52" />
      <circle cx="200" cy="150" r="3" fill="currentColor" />
    </>
  ),
  box: (
    <>
      <line x1="20" y1="20" x2="380" y2="20" />
      <rect x="95" y="20" width="210" height="96" />
      <rect x="150" y="20" width="100" height="38" />
      <path d="M160 116 A52 52 0 0 0 240 116" />
      <circle cx="200" cy="86" r="3" fill="currentColor" />
    </>
  ),
  corner: (
    <>
      <line x1="20" y1="280" x2="380" y2="280" />
      <line x1="20" y1="20" x2="20" y2="280" />
      <path d="M20 232 A48 48 0 0 1 68 280" />
      <rect x="20" y="148" width="96" height="132" />
    </>
  ),
  halfway: (
    <>
      <line x1="20" y1="150" x2="380" y2="150" />
      <path d="M148 150 A52 52 0 0 1 252 150" />
      <path d="M148 150 A52 52 0 0 0 252 150" />
      <line x1="20" y1="20" x2="20" y2="280" />
      <line x1="380" y1="20" x2="380" y2="280" />
    </>
  ),
  arc: (
    <>
      <path d="M20 280 A260 260 0 0 1 280 20" />
      <path d="M20 280 A160 160 0 0 1 180 120" />
      <circle cx="20" cy="280" r="4" fill="currentColor" />
    </>
  ),
}

export function PitchMarking({ variant = 'centre', className = '' }) {
  return (
    <svg
      viewBox="0 0 400 300"
      preserveAspectRatio="xMidYMid slice"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      aria-hidden="true"
      focusable="false"
      className={className}
    >
      {drawings[variant] ?? drawings.centre}
    </svg>
  )
}
