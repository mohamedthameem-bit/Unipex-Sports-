import { Fragment } from 'react'

/**
 * Looping announcement strip. The text is repeated enough times to fill
 * any viewport; the second half is hidden from assistive tech.
 */
export function Marquee({ text, repeat = 6, className = '' }) {
  const half = (hidden) => (
    <div className="flex shrink-0 items-center" aria-hidden={hidden || undefined}>
      {Array.from({ length: repeat }).map((_, i) => (
        <Fragment key={i}>
          <span className="display px-6 text-[1.35rem] whitespace-nowrap sm:text-3xl">{text}</span>
          <span aria-hidden="true" className="inline-block h-3 w-3 rotate-45 bg-current" />
        </Fragment>
      ))}
    </div>
  )
  return (
    <div className={`marquee overflow-hidden ${className}`} role="marquee" aria-label={text}>
      <div className="marquee-track">
        {half(false)}
        {half(true)}
      </div>
    </div>
  )
}
