import { Star } from 'lucide-react'

/** Star row with fractional fill (4.7 fills four stars and 70% of the fifth). */
export function Stars({ value, size = 22, className = '' }) {
  return (
    <span
      className={`inline-flex gap-1 ${className}`}
      role="img"
      aria-label={`Rated ${value} out of 5`}
    >
      {Array.from({ length: 5 }).map((_, i) => {
        const fill = Math.max(0, Math.min(1, value - i))
        return (
          <span key={i} className="relative inline-block" style={{ width: size, height: size }}>
            <Star size={size} strokeWidth={1.5} className="absolute inset-0 text-current opacity-30" />
            <span className="absolute inset-0 overflow-hidden" style={{ width: `${fill * 100}%` }}>
              <Star size={size} strokeWidth={1.5} fill="currentColor" className="text-current" />
            </span>
          </span>
        )
      })}
    </span>
  )
}
