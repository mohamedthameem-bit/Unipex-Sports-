import { useMemo, useState } from 'react'
import { Menu, Search } from 'lucide-react'
import { Button } from '../ui/Button'
import { Wordmark } from '../ui/Wordmark'
import { WhatsAppIcon } from '../ui/WhatsAppIcon'
import { MobileMenu } from './MobileMenu'
import { SearchDialog } from './SearchDialog'
import { navLinks } from '../../config/content'
import { whatsappMessages } from '../../config/site'
import { whatsappUrl } from '../../lib/links'
import { useScrolled } from '../../hooks/useScrolled'
import { useActiveSection } from '../../hooks/useActiveSection'

const iconButton =
  'grid h-11 w-11 place-items-center text-stadium transition-colors hover:text-lime'

export function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const scrolled = useScrolled(40)

  // Sections the nav links point at, so the current one can be marked.
  const sectionIds = useMemo(
    () => ['home', 'collections', 'custom', 'about', 'reviews', 'gallery', 'contact'],
    [],
  )
  const active = useActiveSection(sectionIds)
  const currentHref = (href) => {
    const id = href.slice(1)
    if (id === 'jerseys' || id === 'equipment') return active === 'collections'
    return id === active
  }

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
          scrolled ? 'border-b border-stadium/10 bg-pitch/95 backdrop-blur' : 'bg-transparent'
        }`}
      >
        <div className="mx-auto flex h-[4.5rem] max-w-[1600px] items-center justify-between gap-6 px-5 sm:px-8">
          <a href="#home" aria-label="Unipex Sports, back to top" className="shrink-0">
            <Wordmark />
          </a>

          <nav aria-label="Primary" className="hidden lg:block">
            <ul className="flex items-center gap-8">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    aria-current={currentHref(link.href) ? 'true' : undefined}
                    className="link-draw text-sm font-bold tracking-wide text-stadium"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="flex items-center gap-1 sm:gap-2">
            <button
              type="button"
              className={iconButton}
              aria-label="Search products"
              onClick={() => setSearchOpen(true)}
            >
              <Search size={21} />
            </button>
            <a
              className={iconButton}
              href={whatsappUrl(whatsappMessages.general)}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Message Unipex Sports on WhatsApp"
            >
              <WhatsAppIcon size={22} />
            </a>
            <Button href="#collections" className="ml-2 hidden sm:inline-flex">
              Shop now
            </Button>
            <button
              type="button"
              className={`${iconButton} lg:hidden`}
              aria-label="Open menu"
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
              onClick={() => setMenuOpen(true)}
            >
              <Menu size={26} />
            </button>
          </div>
        </div>
      </header>

      <MobileMenu open={menuOpen} onClose={() => setMenuOpen(false)} />
      <SearchDialog open={searchOpen} onClose={() => setSearchOpen(false)} />
    </>
  )
}
