import { useEffect, useRef } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { X, Phone, MapPin } from 'lucide-react'
import { Button } from '../ui/Button'
import { Wordmark } from '../ui/Wordmark'
import { WhatsAppIcon } from '../ui/WhatsAppIcon'
import { navLinks } from '../../config/content'
import { site, whatsappMessages } from '../../config/site'
import { telUrl, whatsappUrl } from '../../lib/links'
import { useBodyLock } from '../../hooks/useBodyLock'
import { useEscape } from '../../hooks/useEscape'

export function MobileMenu({ open, onClose }) {
  const closeRef = useRef(null)
  const reduce = useReducedMotion()
  useBodyLock(open)
  useEscape(open, onClose)

  useEffect(() => {
    if (open) closeRef.current?.focus()
  }, [open])

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          id="mobile-menu"
          role="dialog"
          aria-modal="true"
          aria-label="Menu"
          className="grain fixed inset-0 z-[60] flex flex-col overflow-y-auto bg-pitch px-5 pb-8 pt-4 lg:hidden"
          initial={reduce ? false : { clipPath: 'inset(0 0 100% 0)' }}
          animate={{ clipPath: 'inset(0 0 0% 0)' }}
          exit={reduce ? undefined : { clipPath: 'inset(0 0 100% 0)' }}
          transition={{ duration: 0.35, ease: [0.2, 0.7, 0.2, 1] }}
        >
          <div className="relative z-10 flex items-center justify-between">
            <Wordmark />
            <button
              ref={closeRef}
              type="button"
              onClick={onClose}
              aria-label="Close menu"
              className="grid h-11 w-11 place-items-center border-2 border-stadium/40 text-stadium transition-colors hover:bg-stadium hover:text-pitch"
            >
              <X size={22} />
            </button>
          </div>

          <nav aria-label="Mobile" className="relative z-10 mt-10 flex flex-col">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={onClose}
                className="display border-b border-stadium/15 py-3 text-[2.6rem] text-stadium transition-colors hover:text-lime"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="relative z-10 mt-auto flex flex-col gap-3 pt-10">
            <Button href={whatsappUrl(whatsappMessages.general)} external variant="lime">
              <WhatsAppIcon size={20} /> WhatsApp us
            </Button>
            <Button href={telUrl} variant="ghost">
              <Phone size={18} /> {site.phone.display}
            </Button>
            <p className="mt-3 flex items-start gap-2 text-sm text-stadium/70">
              <MapPin size={16} className="mt-1 shrink-0" />
              <span>
                {site.address.street}, {site.address.locality}
              </span>
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
