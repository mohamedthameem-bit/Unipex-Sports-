import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { Search, X } from 'lucide-react'
import { Button } from '../ui/Button'
import { WhatsAppIcon } from '../ui/WhatsAppIcon'
import { collections } from '../../config/content'
import { whatsappMessages } from '../../config/site'
import { scrollToHash, whatsappUrl } from '../../lib/links'
import { useBodyLock } from '../../hooks/useBodyLock'
import { useEscape } from '../../hooks/useEscape'

/** Flat list of every catalogue item with the category it belongs to. */
const entries = collections.categories.flatMap((category) =>
  category.items.map((item) => ({ item, category })),
)

export function SearchDialog({ open, onClose }) {
  const [query, setQuery] = useState('')
  const inputRef = useRef(null)
  const reduce = useReducedMotion()
  useBodyLock(open)
  useEscape(open, onClose)

  useEffect(() => {
    if (open) inputRef.current?.focus()
    else setQuery('')
  }, [open])

  const term = query.trim()
  const results = useMemo(() => {
    if (!term) return []
    const needle = term.toLowerCase()
    return entries.filter(
      ({ item, category }) =>
        item.toLowerCase().includes(needle) || category.name.toLowerCase().includes(needle),
    )
  }, [term])

  const go = (anchor) => {
    onClose()
    // wait for the overlay to release the scroll lock before scrolling
    window.setTimeout(() => scrollToHash(`#${anchor}`), 60)
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label="Search products"
          className="fixed inset-0 z-[70] bg-pitch/95 px-5 pt-[12vh] backdrop-blur-sm"
          initial={reduce ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={reduce ? undefined : { opacity: 0 }}
          transition={{ duration: 0.18 }}
          onMouseDown={(e) => e.target === e.currentTarget && onClose()}
        >
          <div className="mx-auto w-full max-w-2xl">
            <div className="flex items-center gap-3 border-b-2 border-stadium pb-3">
              <Search size={26} aria-hidden="true" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                type="search"
                placeholder="Search jerseys, bats, footballs"
                aria-label="Search products"
                autoComplete="off"
                className="display w-full bg-transparent text-3xl text-stadium placeholder:text-stadium/35 focus:outline-none sm:text-4xl"
              />
              <button
                type="button"
                onClick={onClose}
                aria-label="Close search"
                className="grid h-10 w-10 shrink-0 place-items-center text-stadium transition-colors hover:text-lime"
              >
                <X size={24} />
              </button>
            </div>

            <div className="mt-6" aria-live="polite">
              {!term && (
                <p className="text-stadium/60">
                  Type a product or sport to jump to it, or ask the store directly.
                </p>
              )}

              {term && results.length > 0 && (
                <ul className="divide-y divide-stadium/15">
                  {results.map(({ item, category }) => (
                    <li key={`${category.id}-${item}`}>
                      <button
                        type="button"
                        onClick={() => go(category.anchor)}
                        className="group flex w-full items-baseline justify-between gap-4 py-3 text-left"
                      >
                        <span className="display text-2xl text-stadium transition-colors group-hover:text-lime">
                          {item}
                        </span>
                        <span className="shrink-0 text-sm text-stadium/60">{category.name}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}

              {term && results.length === 0 && (
                <p className="text-stadium/80">
                  Nothing in the catalogue called &ldquo;{term}&rdquo;. The shop may still have it.
                </p>
              )}

              {term && (
                <div className="mt-6">
                  <Button
                    href={whatsappUrl(whatsappMessages.search(term))}
                    external
                    variant={results.length ? 'ghost' : 'lime'}
                  >
                    <WhatsAppIcon size={18} /> Ask the store about &ldquo;{term}&rdquo;
                  </Button>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
