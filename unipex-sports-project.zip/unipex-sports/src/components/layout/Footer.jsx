import { footer } from '../../config/content'
import { site, whatsappMessages } from '../../config/site'
import { telUrl, whatsappUrl } from '../../lib/links'
import { WhatsAppIcon } from '../ui/WhatsAppIcon'

const linkClass = 'link-draw font-bold text-stadium'

export function Footer() {
  const { address, hours, phone, maps, socials } = site

  return (
    <footer className="grain overflow-hidden bg-pitch pt-16 sm:pt-20">
      <div className="relative z-10 mx-auto max-w-[1600px] px-5 sm:px-8">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <p className="display text-[clamp(2rem,4vw,3.2rem)]">{site.tagline}</p>
          </div>

          <nav aria-label="Footer" className="md:col-span-3">
            <ul className="grid gap-2">
              {footer.links.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className={linkClass}>
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="grid content-start gap-3 text-stadium/85 md:col-span-4">
            <address className="not-italic">
              {address.lines.map((line) => (
                <span key={line} className="block">
                  {line}
                </span>
              ))}
            </address>
            <a href={telUrl} className={`${linkClass} w-fit`}>
              {phone.display}
            </a>
            <p>
              {hours.label}, {hours.open} to {hours.close}
            </p>
            <ul className="mt-2 flex flex-wrap gap-x-6 gap-y-2">
              <li>
                <a href={maps.listingUrl} target="_blank" rel="noopener noreferrer" className={linkClass}>
                  Google Maps
                </a>
              </li>
              <li>
                <a
                  href={whatsappUrl(whatsappMessages.general)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`${linkClass} inline-flex items-center gap-2`}
                >
                  <WhatsAppIcon size={16} /> WhatsApp
                </a>
              </li>
              {socials.map((social) => (
                <li key={social.href}>
                  <a href={social.href} target="_blank" rel="noopener noreferrer" className={linkClass}>
                    {social.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <p
          aria-hidden="true"
          className="display mt-16 select-none whitespace-nowrap text-center text-[17.5vw] leading-[0.82] text-stadium sm:mt-20"
        >
          UNIPEX SPORTS
        </p>
      </div>

      <div className="relative z-10 border-t border-stadium/15">
        <p className="mx-auto max-w-[1600px] px-5 py-5 text-sm text-stadium/60 sm:px-8">{footer.copyright}</p>
      </div>
    </footer>
  )
}
